library(testthat)
library(EnMCB)

test_check("EnMCB")
